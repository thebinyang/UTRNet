%% WPCD for UTRNet

clear
close all
savepath=pwd;
allmap = load('..\Ground_Truth.mat.mat');
dir_l=pwd;
imf=dir(fullfile(dir_l,'L*')); % folder names
imf = regexpi({imf.name}, 'L(T5|T4|E7|C8|ND)(\w*)', 'match');
imf = [imf{:}];
imf = vertcat(imf{:});
yeardoy = str2num(imf(:, 10:16));
[yeardoy, sort_order] = sort(yeardoy);
imf = imf(sort_order, :);
num_imgs = size(imf,1);
yr = str2num(imf(:, 10:13));
doy = str2num(imf(:, 14:16));
sdate = datenum(yr, 1, 0) + doy;
% name of the first stacked image
filename = dir(fullfile(dir_l,imf(1,:),'L*MTLstack'));
% read in dimension and zone number of the Data
[jiDim,jiUL,resolu,ZC,bands] = envihdrread(fullfile(dir_l,imf(1,:),filename.name));
% dimension of image [row,col]
ijdim = [jiDim(2),jiDim(1)];
% number of nrows processed
nrows = ijdim(1);
% number of pixels procesed per line
ncols = ijdim(2);

CMM=zeros(nrows,ncols);
for band=[1,2,3,4,5,6]

    for i=1:num_imgs
        
        h=waitbar(0);
        s=sprintf('Processing: %.2f%% ',((band-1)*num_imgs+i)/(num_imgs*6)*100);
        waitbar(((band-1)*num_imgs+i)/(num_imgs*6),h,s);
        
        im_dir = dir(fullfile(dir_l,imf(i, :)));
        im = '';
        for f = 1:size(im_dir, 1)
            if regexp(im_dir(f).name, ['L(\w*)', 'stack', '$']) == 1
                im = fullfile(dir_l,imf(i, :), im_dir(f).name);
                break
            end
        end
        IM = enviread(im);
        IM100=permute(IM,[1,3,2]);
        IM100=permute(IM100,[2,1,3]);
        data(i,:,:,:) = IM100(1:6,:,:);
        Fmask=IM(:,:,8);
        for row=1:nrows
            for col=1:ncols
                if Fmask(row,col)>1
                    IM(row,col,1:7)=-9999;
                    Data(row,col,i)=IM(row,col,band);
                else
                    Data(row,col,i)=IM(row,col,band);
                end
            end
        end
         Data(:,:,i)=IM(:,:,band);
    end
    data(data==-9999)=0;
    save([savepath,'\data.mat'],'data','allmap')
    for row=1:nrows
        for col=1:ncols
            T3=Data(row,col,:);
            T3=T3(:);
            idgood=find(T3(:)~=-9999);
            clrx=sdate(idgood);
            clry=double(T3(idgood));
            [fit_cft,rmse,v_dif]=autoTSFit1(clrx,clry,8,0,1);
            rmseMAP(row,col)=rmse;
        end
    end
    rmseMAP(isnan(rmseMAP))=0;
    MAP=rmseMAP;
    I=rmseMAP(:);
    I = sort(I);
    Tomax=I(floor(length(I)*0.999));
    MAP(MAP>=Tomax)=Tomax;
    thresh = multithresh(MAP,1);
    seg_c = imquantize(MAP,thresh)-1;
    chang_map(:,:,band)=seg_c;
    seg_no = imquantize(MAP,thresh)-1;
    nochang_map(:,:,band)=1-seg_no;
end  
   MAP3=zeros(nrows,ncols);
   MAP4=zeros(nrows,ncols);
   IDX_map=zeros(nrows,ncols);
   for band=1:6
       MAP3=MAP3+chang_map(:,:,band);
       MAP4=MAP4+nochang_map(:,:,band);
   end
   W=MAP3/6;
   W(W<mean2(W))=mean2(W);
   change=MAP3>=4;
   nochange=MAP4>=5;
   
   imshow(change,[])
   [idx_row3,idx_col3]=find(change==1);
   train_change=[idx_row3,idx_col3];
   [idx_row4,idx_col4]=find(nochange==1);
   train_nochange=[idx_row4,idx_col4];
   for i=1:length(train_change)
       IDX_map(train_change(i,1),train_change(i,2))=1;
   end
   for i=1:length(train_nochange)
       IDX_map(train_nochange(i,1),train_nochange(i,2))=2;
   end
   save([savepath,'\IDX_map.mat'],'IDX_map','change','nochange','W')


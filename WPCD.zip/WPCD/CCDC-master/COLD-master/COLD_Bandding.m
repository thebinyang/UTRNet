  function COLD_Bandding(row,col,varargin)

%% ���ļ����ж�ȡͼ�����ڣ����������ַ�ת��Ϊ����date_num
% dir_l = pwd;
dir_l ='F:\test right\No repair\13-19 (7and8) 75';
p = inputParser;
p.FunctionName = 'paras';
addParameter(p,'sNDVIDir',dir_l);

parse(p,varargin{:});
dir_l = p.Results.sNDVIDir;

%% Constants: 
% get num of total folders start with "L"
imf=dir(fullfile(dir_l,'L*')); % folder names
% number of images
num_imgs = size(imf,1);
% filter for Landsat folders
imf = regexpi({imf.name}, 'L(T5|T4|E7|C8|ND)(\w*)', 'match');
imf = [imf{:}];
imf = vertcat(imf{:});
% sort according to yeardoy
yeardoy = str2num(imf(:, 10:16));
[y, sort_order] = sort(yeardoy);
imf = imf(sort_order, :);
% name of the first stacked image
filename = dir(fullfile(dir_l,imf(1,:),'L*MTLstack')); 
% read in dimension and zone number of the data
[jiDim,~,~,~] = envihdrread(fullfile(dir_l,imf(1,:),filename.name));
% dimension of image [row,col]
ijdim = [jiDim(2),jiDim(1)];
% number of nrows processed
nrows = ijdim(1);
% number of pixels procesed per line
ncols = ijdim(2);
% total ouput bands (1-5,7,6,cfmask)
nbands = 8;
imf=dir(fullfile(dir_l,'L*')); % folder names
% filter for Landsat folders
imf = regexpi({imf.name}, 'L(T5|T4|E7|C8|ND)(\w*)', 'match');
imf = [imf{:}];
imf = vertcat(imf{:});
% number of images
num_imgs = size(imf,1);
% sort according to yeardoy
% yeardoy = str2num(imf(:, 10:16));
% [~, sort_order] = sort(yeardoy);
% imf = imf(sort_order, :);
% % name of the first stacked image
% filename = dir(fullfile(dir_l,imf(1,:),'L*')); 
% row = 107;% change pixel
% col = 447;
%  row = 200;% no change pixel
%  col = 285;
for i=1:num_imgs
    im_dir = dir(fullfile(dir_l,imf(i, :)));
    im = '';
    for f = 1:size(im_dir, 1)
        % use regular expression to match:
        %   'L(\w*)'    Any word begining with L that has any following chars
        %   stk_n       includes stack name somewhere after L
        %   '$'           ends with the stack name (e.g., no .hdr, .aux.xml)
        if regexp(im_dir(f).name, ['L(\w*)', 'stack', '$']) == 1
            im = fullfile(dir_l,imf(i, :), im_dir(f).name);
            break
        end
    end
    % Check to make sure we found something
    if strcmp(im, '')
        error('Could not find stack image for directory %s\n', imf(i));
    end
    % Find date for folder imf(i)
    yr = str2num(imf(i, 10:13));
    doy = str2num(imf(i, 14:16));
    sdate(i) = datenum(yr, 1, 0) + doy; 
   
end
% profile viewer
% exit
% end % end of function 
% (nrows-1)*ncols+i_ids;
   
%% �Զ������仯��ı仯ʱ��t_break
t_break=0;
k=1;K=1;
filename=['F:\test right\No repair\189 no repair\Result_COLD\TSFitMap\record_change' num2str(row) '.mat'];
load(filename);  
pp=(row-1)*ncols+col;
    for j=1:size(rec_cg,2)
       pos=rec_cg(j).pos;
       if pos==pp && rec_cg(j).t_break~=0
           t_break(k)=rec_cg(j).t_break;                
           t_start(k)=rec_cg(j).t_start;    
           t_end(k)=rec_cg(j).t_end;   
           t_pos(k)=rec_cg(j).pos;
           t_num_obs(k)=rec_cg(j).num_obs;
           t_category1(k)=rec_cg(j).category;
           k=k+1;
       elseif pos==pp && rec_cg(j).t_break==0
           t_category2(K)=rec_cg(j).category;
           break
       end
       
    end   
imdate= datestr(t_break,'yyyy-mm-dd');

%% ���۲��Ĳ��η���ֵƽ��    
% load('F:\test right\repair\Result\13-19 (7and8) 75 single repair result\result.mat');%CCDC�����
for i=1:num_imgs
    im_dir = dir(fullfile(dir_l,imf(i, :)));
    im = '';
    for f = 1:size(im_dir, 1)
        % use regular expression to match:
        %   'L(\w*)'    Any word begining with L that has any following chars
        %   stk_n       includes stack name somewhere after L
        %   '$'           ends with the stack name (e.g., no .hdr, .aux.xml)
        if regexp(im_dir(f).name, ['L(\w*)', 'stack', '$']) == 1
            im = fullfile(dir_l,imf(i, :), im_dir(f).name);
            break
        end
    end
    % Check to make sure we found something
    if strcmp(im, '')
        error('Could not find stack image for directory %s\n', imf(i));
    end
    date= enviread(im);
    A(2:9,i)=double(date(row,col,1:8));
    
    fmask(i)=date(row,col,8);
end
    A(1,:)=sdate(1,:);
    A=double(A);
    A=A';
    A=sortrows(A,1);
    m=1;
for k=1:num_imgs
    if A(k,9)==0
        C(m,:)=A(k,:);
        m=m+1;
    end
end
%% ������� 
    for i=1:7
     band=i+1;%%%%%   %%%%%%%ѡ�񲨶�band
     x=1;y=1;
      for n=1:size(C,1)
           if C(n,1)>datenum(1999,01,01) && C(n,1)<t_break 
             a(x,1)=C(n,band); 
             b(x,1)=C(n,1) ;
             x=x+1;  
           elseif C(n,1)>t_break && C(n,1)<datenum(2020,01,01) 
             c(y,1)=C(n,band); 
             d(y,1)=C(n,1) ;
             y=y+1; 
           end
     end


      createFit(b,a,d,c,band);
%       f=getframe(gcf);
%       imwrite(f.cdata,['F:\test\single\','band',int2str(band),'.tiff']);
    end
  end
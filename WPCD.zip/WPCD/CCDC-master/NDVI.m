  function NDVI(varargin)
% Matlab code for NDVI

% Get variable and path 
dir_l = pwd; %'/projectnb/landsat/projects/LCMS/4530/images/'; 
p = inputParser;
p.FunctionName = 'paras';
addParameter(p,'NDVIDir',dir_l);

parse(p,varargin{:});
dir_l = p.Results.NDVIDir;

%% Constants: 


% get num of total folders start with "L"
imf=dir(fullfile(dir_l,'L*')); % folder names
% number of images
num_imgs = size(imf,1);
% filter for Landsat folders
imf = regexpi({imf.name}, 'L(T5|T4|E7|C8|ND)(\w*)', 'match');
imf = [imf{:}];
imf = vertcat(imf{:});
% sort according to yeardoy
yeardoy = str2num(imf(:, 10:16));
[~, sort_order] = sort(yeardoy);
imf = imf(sort_order, :);
% name of the first stacked image
filename = dir(fullfile(dir_l,imf(1,:),'L*MTLstack')); 
% read in dimension and zone number of the data
[jiDim,~,~,~] = envihdrread(fullfile(dir_l,imf(1,:),filename.name));
% dimension of image [row,col]
ijdim = [jiDim(2),jiDim(1)];
% number of nrows processed
nrows = ijdim(1);
% number of pixels procesed per line
ncols = ijdim(2);
% total ouput bands (1-5,7,6,cfmask)
nbands = 8;

% folder name of all CCDC results 
name_rst = 'NDVI';
% make TSFitMap folder for storing coefficients
if isempty(dir(fullfile(dir_l,name_rst)))
    mkdir(fullfile(dir_l,name_rst));
end
for i=1:num_imgs
    im_dir = dir(fullfile(dir_l,imf(i, :)));
    im = '';
    for f = 1:size(im_dir, 1)
        % use regular expression to match:
        %   'L(\w*)'    Any word begining with L that has any following chars
        %   stk_n       includes stack name somewhere after L
        %   '$'           ends with the stack name (e.g., no .hdr, .aux.xml)
        if regexp(im_dir(f).name, ['L(\w*)', 'stack', '$']) == 1
            im = fullfile(dir_l,imf(i, :), im_dir(f).name);
            break
        end
    end
    % Check to make sure we found something
    if strcmp(im, '')
        error('Could not find stack image for directory %s\n', imf(i));
    end
    % Find date for folder imf(i)
%     yr = str2num(imf(i, 10:13));
%     doy = str2num(imf(i, 14:16));
%     sdate(i) = datenum(yr, 1, 0) + doy; 
    date= enviread(im);
    red=double(date(:,:,3));%the date of Band3 (Red)
    nir=double(date(:,:,4));%the date of Band4 (NIR)
    ndvi=double((nir-red)./(nir+red));%the date of NDVI
    ndvi(isnan(ndvi)) = 0;
    save(fullfile(dir_l,name_rst,[imf(i,:)]),'ndvi');
end
% profile viewer
% exit
% end % end of function 
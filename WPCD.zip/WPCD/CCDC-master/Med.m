 function y=Med(x)
   A=sort(x);
   [num,~]=size(A);
   k=1;
   for i=1:num
       if i>=num*0.9
           C(k,:)=A(i,:);
            k=k+1;
       end   
   end

   y=median(C);
 
 end

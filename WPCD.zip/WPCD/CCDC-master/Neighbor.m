 function y=Neighbor(x)
   A=sort(x);
   [num,~]=size(A);

   k=1;
%    num2=length(find(A==1));
%        if num2>=num/2
%           C=ones(num);
%        else C=zeros(num);
%        end   
% 
   y=max(A);
 
 end
function OUT = lt(varargin)

funname = 'lt';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});
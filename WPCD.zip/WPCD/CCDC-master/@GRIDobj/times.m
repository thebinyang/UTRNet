function OUT = times(varargin)

funname = 'times';
narginchk(2,2)
OUT = builtincaller(funname,varargin{:});
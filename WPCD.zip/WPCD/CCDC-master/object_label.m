 function [out]=object_label(A,R,roi)
%       s = load(A);
%       sc=struct2cell(s);  
%       all_label=cell2mat(sc);  
     out=zeros(363,625);
     all_label=A;
%      R=geotiffinfo('F:\CCDC\CCDC-master\New_CCDC\object_GLCM\LC08_L1TP_125045_20161228_20170314_01_T1_b5.tif');
     [xx,yy]=pixcenters(R);
     [XX,YY]=meshgrid(xx,yy);
     Rxx=XX(52:52+363-1,82:82+625-1);
     Ryy=YY(52:52+363-1,82:82+625-1);
%  roi=shaperead('F:\test\eCongnition\2016363 clear\9X9\9X9.shp');
% roi=shaperead('F:\test\eCongnition\2016363 clear\15 0.7 0.2\15 0.7 0.2.shp');
     comm_i = find(all_label == -1);
     num_roi=length(comm_i);
     for k=1:num_roi
         m=comm_i(k);
         rx=roi(m).X;
         ry=roi(m).Y;
         rxx=rx(1:end-1);
         ryy=ry(1:end-1);
         mask=(inpolygon(Rxx,Ryy,rxx,ryy));%imshow(mask);
         if k==1
             out=mask;
         else
             out=out+mask;
         end
     end

 end
% B=B';
% [data,PS]=mapminmax(B,-1,1);% ���н��й�һ��   % K=mapminmax('reverse',B,PS) %���չ�һ�����򷵻�ԭ����
% data=data';
% C = sparse(data);% ����ϡ�����
% load('F:\CCDC\CCDC-master\libsvm-master\libsvm-3.1-[FarutoUltimate3.1Mcode]\matlab\label.mat')
% libsvmwrite('libsvm_data',label, C); 
%save('mydata.mat', 'val1', 'val2'); % �������val1,val2��1_result.mat��
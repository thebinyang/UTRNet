# -*- coding: utf-8 -*-
"""
Created on Thu Apr 29 10:30:10 2021
无监督
up-to-date 2021/11/08
@author: thebi test
"""
from scipy.io import loadmat
import gdal
import numpy as np
import pickle
from tqdm import tqdm
import matplotlib.pyplot as plt

def norm_img(img, channel_first=True):
    if channel_first:
        channel, img_height, img_width = img.shape
        img = np.reshape(img, (channel, img_height * img_width))  # (channel, height * width)
        max_value = np.max(img, axis=1, keepdims=True)  # (channel, 1)
        min_value = np.min(img, axis=1, keepdims=True)  # (channel, 1)
        diff_value = max_value - min_value
        nm_img = (img - min_value) / diff_value
        nm_img = np.reshape(nm_img, (channel, img_height, img_width))
    else:
        img_height, img_width, channel = img.shape
        img = np.reshape(img, (img_height * img_width, channel))  # (channel, height * width)
        max_value = np.max(img, axis=0, keepdims=True)  # (channel, 1)
        min_value = np.min(img, axis=0, keepdims=True)  # (channel, 1)
        diff_value = max_value - min_value
        nm_img = (img - min_value) / diff_value
        nm_img = np.reshape(nm_img, (img_height, img_width, channel))
    return nm_img


path = r'../data'
data_set_train = loadmat(path + '/' + 'data.mat')['data']
val_set = loadmat(path + '/' + 'data.mat')['allmap']
IDX_map = loadmat(path + '/' + 'IDX_map.mat')['IDX_map']
W = loadmat(path + '/' + 'IDX_map.mat')['W']
num_map = data_set_train.shape[2] * data_set_train.shape[3]

num_all = 0
num_test = 0
for i in range(0, val_set.shape[0]):
    for j in range(0, val_set.shape[1]):
        if IDX_map[i, j] > 0:
                num_all += 1
        if val_set[i, j] > 0:
                num_test += 1

patch_sz = 5
edge = patch_sz // 2
map_sample = np.zeros((10, num_map, patch_sz, patch_sz, 6), dtype='float32')
all_sample = np.zeros((10, num_all, patch_sz, patch_sz, 6),dtype='float32')
test_sample = np.zeros((10, num_test, patch_sz, patch_sz, 6),dtype='float32')
for m in tqdm(range(0, 10)):
    img_X = data_set_train[m, :, :, :]

    # img_X = stad_img(img_X)  # (C, H, W)
    img_X =norm_img(img_X)  # (C, H, W)

    img_X = np.transpose(img_X, [1, 2, 0])  # (H, W, C)

    img_height, img_width, channel = img_X.shape  # image width

    img_X = np.pad(img_X, ((edge, edge), (edge, edge), (0, 0)), 'constant')
    tt = img_X[:, :, 1]
    all_X = []
    map_X =[]
    test_X = []
    test_W = []
    if m == 0:
        all_label = []
        test_label = []
        all_W=[]
    for i in range(edge, img_height + edge):
        for j in range(edge, img_width + edge):
            map_X.append(img_X[i - edge:i + edge + 1, j - edge:j + edge + 1, :])
            if IDX_map[i - edge, j - edge] > 0:
                    if m == 0:
                        all_X.append(img_X[i - edge:i + edge + 1, j - edge:j + edge + 1, :])
                        all_label.append(IDX_map[i - edge, j - edge])
                        all_W.append(W[i - edge, j - edge])
                    else:
                        all_X.append(img_X[i - edge:i + edge + 1, j - edge:j + edge + 1, :])
            if val_set[i - edge, j - edge] > 0:
                    if m == 0:
                        test_X.append(img_X[i - edge:i + edge + 1, j - edge:j + edge + 1, :])
                        test_label.append(val_set[i - edge, j - edge])
                        # test_W.append(W[i - edge, j - edge])
                    else:
                        test_X.append(img_X[i - edge:i + edge + 1, j - edge:j + edge + 1, :])

    map_sample[m, :, :, :, :] = np.array(map_X)
    all_sample[m, :, :, :, :] = np.array(all_X)
    test_sample[m, :, :, :, :] = np.array(test_X)

all_W = np.array(all_W)
all_label = np.array(all_label)
test_label = np.array(test_label)

outpath1 = open(path + '\\all_sample.pickle', 'wb')
pickle.dump(all_sample, outpath1)

outpath2 = open(path+'\\all_label.pickle', 'wb')
pickle.dump(all_label, outpath2)

outpath3 = open(path+'\\all_W.pickle', 'wb')
pickle.dump(all_W, outpath3)

outpath4 = open(path + '\\test_sample.pickle', 'wb')
pickle.dump(test_sample, outpath4)

outpath5 = open(path+'\\test_label.pickle', 'wb')
pickle.dump(test_label, outpath5)

outpath6 = open(path + '\\all_map.pickle', 'wb')
pickle.dump(map_sample, outpath6, protocol=4)







